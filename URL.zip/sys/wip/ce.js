/*if (window.location != window.parent.location) {

  var parent = document.referrer;
  document.getElementById("parent").innerHTML = parent;
  
}*/

/*chrome.tabs.query({active: true, lastFocusedWindow: true}, tabs => {
    let url = tabs[0].url;
    // use `url` here inside the callback because it's asynchronous!
});

*/

